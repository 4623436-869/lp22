import React from "react";

function Inicio(){
    return <h1 className="font-bold text-lg mt-8">Página de Inicio</h1>
}

export default Inicio;