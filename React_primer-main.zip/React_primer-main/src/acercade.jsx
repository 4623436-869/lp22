import React from "react";

function AcercaDe() {
    return <h1 className="font-bold text-lg mt-8">Acerca de Nosotros</h1>
  }
export default AcercaDe;