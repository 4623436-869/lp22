import React from "react";

function Contacto() {
    return <h1 className="font-bold text-lg mt-8">Página de Contacto</h1>    
}

export default Contacto;